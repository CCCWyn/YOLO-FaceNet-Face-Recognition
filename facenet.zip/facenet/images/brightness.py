#提高图像亮度与对比度

from skimage import data, exposure, img_as_float
import matplotlib.pyplot as plt
from skimage import io
import os

file_pathname = 'D:/Anaconda/FaceRecognition-master/face_images/tang_rong'
for filename in os.listdir(file_pathname):
    img = io.imread(file_pathname + '/' + filename)
    image = img_as_float(img)  # 把图片从uint8转换成float364用于运算
    gam = exposure.adjust_gamma(image, 0.5)  # 调亮
    '''保存图像'''
    io.imsave('D:/Anaconda/FaceRecognition-master/face_images/jiang' + "/" + filename, gam)





